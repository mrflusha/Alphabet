This font is distributed under a Creative Commons license.
The only condition for the free use of the font is the attribution in the form: Brat developed by 
Alexandra Botvinova at HSE ART AND DESIGN SCHOOL

Этот шрифт распространяется по лицензии Creative Commons.
Единственное условие бесплатного использования шрифта — это указание авторства в виде: Брат разработан Александрой Ботвиновой в Школе дизайна НИУ ВШЭ 

https://hsedesignlab.ru/hsefonts

https://www.behance.net/berserkgodc0d8

