I AMBLOCK is a monospaces square display font.

An early Colt Type Co font and is now free.

https://wearecolt.com/

