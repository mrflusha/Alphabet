In 2019 we celebrated the centennial of Bauhaus and in 2020 we are going to celebrate the centennials of VKhUTEMAS and UNOVIS — schools that gave birth to Constructivism and Suprematism.
In honor of these events, I created a free Suprematist typeface, inspired by Malevich's lettering (found in the Dr. Mabuzo poster) and Joseph Albers' typefaсe experiments.
It is best suited for poster design, logotypes, and short headlines.

SIL Open Font License v1.1
You can use it for commercial work and share (with the name of the author).
Selling and modify prohibited


В 2019 году мы праздновали столетие Баухаус, в 2020-м году отмечаем юбилей ВХУТЕМАС и УНОВИС - школ, в которых родились конструктивизм и супрематизм.
В честь этих событий я создал бесплатный супрематический шрифт.
Основан на леттеринге Малевича (из плаката Доктор Мабузо) и шрифтовых экспериментах Йозефа Альберса.
Подходит для дизайна плакатов, логотипов и коротких заголовков.

Вы можете использовать его для коммерческой работы и делиться (с указанием имени автора).
Запрещено продавать и модифицировать.

https://www.behance.net/Denis_Masharov






